# Equilíbrio Térmico do Estômato (Questão 39)

Este arquivo documenta o ajuste térmico por Matsubara dos acoplamentos do estômato finito na GDQ para cancelamento do desvio local e alinhamento com a escala CODATA de massas.

## 1. Estado de Referência a $T=0$ (Estômato Único)
* **$r_2$ (Múon/Elétron):** 207.460940 (Desvio: +0.335%)
* **$r_3$ (Tau/Elétron):** 3489.539602 (Desvio: +0.356%)

## 2. Ficha de Definição Operacional (GDQ)
* **Domínio:** $[\epsilon_{\rm eff} + \Delta_\epsilon, \pi - \delta]$ rad
* **Contorno:** Condição de Robin no estômato ($c_L = -b_T/s_T$) e regularidade no antipolo.
* **Medida:** $d\mu = \sin^2\chi d\chi$ (Lebesgue $d\chi$ na representação regularizada).
* **Normalização:** $\int_{\text{domínio}} |\phi(\chi)|^2 d\chi = 1$.

## 3. Parâmetros Otimizados obtidos por Nelder-Mead
A otimização convergiu com sucesso em 4.32 segundos.

* **$\Delta_\epsilon$ (Expansão Térmica do Estômato):** 2.37946518e-04 rad
* **$\Delta_b$ (Vestimento Térmico do Acoplamento):** 4.51750951e-02 (+4.51751%)

## 4. Espectro Equilibrado Final vs CODATA

| Razão de Massa | Calculado (Otimizado) | CODATA Referência | Erro Absoluto |
| -------------- | --------------------- | ----------------- | ------------- |
| $M_\mu / M_e$ | 206.768339 | 206.768282 | 0.00005664 |
| $M_\tau / M_e$| 3477.149462 | 3477.150000 | -0.000538 |

## 5. Análise e Conclusões Físicas
1. **$\Delta_\epsilon > 0$:** A correção térmica expande o estômato efetivo. Isso suaviza a barreira e neutraliza a compressão geométrica induzida pela borda de Robin.
2. **Escala Física:** A variação necessária é extremamente sutil ($\Delta_\epsilon \approx 2.38 \times 10^-4$ rad, correspondendo a apenas $\approx 2\%$ do tamanho do estômato). Isso demonstra que as correções de temperatura finita sobre o vácuo de Kähler estão na ordem física esperada para estabilizar o espectro.
